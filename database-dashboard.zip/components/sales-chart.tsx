"use client"

import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import { Line, LineChart, XAxis, YAxis } from "recharts"

const data = [
  { month: "Jan", sales: 4000 },
  { month: "Feb", sales: 3000 },
  { month: "Mar", sales: 5000 },
  { month: "Apr", sales: 2780 },
  { month: "May", sales: 1890 },
  { month: "Jun", sales: 2390 },
  { month: "Jul", sales: 3490 },
  { month: "Aug", sales: 4000 },
  { month: "Sep", sales: 2780 },
  { month: "Oct", sales: 1890 },
  { month: "Nov", sales: 3578 },
  { month: "Dec", sales: 5200 },
]

export function SalesChart() {
  return (
    <ChartContainer
      config={{
        sales: {
          label: "Sales",
          color: "hsl(var(--chart-1))",
        },
      }}
      className="h-[300px]"
    >
      <LineChart
        data={data}
        margin={{
          top: 5,
          right: 10,
          left: 10,
          bottom: 0,
        }}
      >
        <XAxis dataKey="month" tickLine={false} axisLine={false} tickMargin={10} />
        <YAxis tickFormatter={(value) => `R$${value}`} tickLine={false} axisLine={false} tickMargin={10} />
        <Line type="monotone" dataKey="sales" strokeWidth={2} activeDot={{ r: 6 }} stroke="var(--color-sales)" />
        <ChartTooltip
          content={
            <ChartTooltipContent
              labelFormatter={(value) => `${value}`}
              valueFormatter={(value) => `R$${value.toLocaleString()}`}
            />
          }
        />
      </LineChart>
    </ChartContainer>
  )
}

