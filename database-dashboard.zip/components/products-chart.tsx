"use client"

import { Cell, Pie, PieChart } from "recharts"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"

const data = [
  { name: "Electronics", value: 400 },
  { name: "Clothing", value: 300 },
  { name: "Food", value: 300 },
  { name: "Home", value: 200 },
  { name: "Other", value: 100 },
]

export function ProductsChart() {
  return (
    <ChartContainer
      config={{
        Electronics: {
          label: "Electronics",
          color: "hsl(var(--chart-1))",
        },
        Clothing: {
          label: "Clothing",
          color: "hsl(var(--chart-2))",
        },
        Food: {
          label: "Food",
          color: "hsl(var(--chart-3))",
        },
        Home: {
          label: "Home",
          color: "hsl(var(--chart-4))",
        },
        Other: {
          label: "Other",
          color: "hsl(var(--chart-5))",
        },
      }}
      className="h-[300px]"
    >
      <PieChart>
        <Pie data={data} cx="50%" cy="50%" labelLine={false} outerRadius={80} fill="#8884d8" dataKey="value">
          {data.map((entry, index) => (
            <Cell key={`cell-${index}`} fill={`var(--color-${entry.name})`} />
          ))}
        </Pie>
        <ChartTooltip
          content={
            <ChartTooltipContent
              labelFormatter={(value) => `${value}`}
              valueFormatter={(value) => `R$${value.toLocaleString()}`}
            />
          }
        />
      </PieChart>
    </ChartContainer>
  )
}

