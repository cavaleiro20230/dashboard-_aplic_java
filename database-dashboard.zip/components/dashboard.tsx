"use client"

import { useState } from "react"
import { BarChart, FileText, Filter, PieChart, RefreshCw, TrendingUp } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { DateRangePicker } from "@/components/date-range-picker"
import { SalesChart } from "@/components/sales-chart"
import { ProductsChart } from "@/components/products-chart"
import { RevenueMetric } from "@/components/revenue-metric"
import { DataTable } from "@/components/data-table"
import { FilterDrawer } from "@/components/filter-drawer"

export default function Dashboard() {
  const [isLoading, setIsLoading] = useState(false)
  const [isFilterOpen, setIsFilterOpen] = useState(false)

  const refreshData = async () => {
    setIsLoading(true)
    // In a real implementation, this would trigger a refresh of all data
    await new Promise((resolve) => setTimeout(resolve, 1000))
    setIsLoading(false)
  }

  return (
    <div className="flex flex-col h-full">
      <header className="border-b bg-card">
        <div className="container flex items-center justify-between py-4">
          <h1 className="text-2xl font-bold">Business Analytics Dashboard</h1>
          <div className="flex items-center gap-4">
            <DateRangePicker />
            <Button variant="outline" size="icon" onClick={() => setIsFilterOpen(true)}>
              <Filter className="h-4 w-4" />
              <span className="sr-only">Filter</span>
            </Button>
            <Button variant="outline" size="icon" onClick={refreshData} disabled={isLoading}>
              <RefreshCw className={`h-4 w-4 ${isLoading ? "animate-spin" : ""}`} />
              <span className="sr-only">Refresh data</span>
            </Button>
          </div>
        </div>
      </header>

      <div className="container py-6 space-y-6 flex-1">
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <RevenueMetric
            title="Total Revenue"
            value="R$ 45.231,89"
            trend="+12.5%"
            description="Compared to last month"
            icon={<TrendingUp className="h-4 w-4" />}
          />
          <RevenueMetric
            title="Average Order"
            value="R$ 156,78"
            trend="+2.3%"
            description="Compared to last month"
            icon={<BarChart className="h-4 w-4" />}
          />
          <RevenueMetric
            title="Total Orders"
            value="289"
            trend="+18.7%"
            description="Compared to last month"
            icon={<FileText className="h-4 w-4" />}
          />
          <RevenueMetric
            title="Conversion Rate"
            value="3.45%"
            trend="-0.5%"
            trendNegative={true}
            description="Compared to last month"
            icon={<PieChart className="h-4 w-4" />}
          />
        </div>

        <Tabs defaultValue="charts">
          <TabsList>
            <TabsTrigger value="charts">Charts</TabsTrigger>
            <TabsTrigger value="reports">Reports</TabsTrigger>
            <TabsTrigger value="data">Raw Data</TabsTrigger>
          </TabsList>
          <TabsContent value="charts" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>Sales by Period</CardTitle>
                  <CardDescription>Monthly sales performance</CardDescription>
                </CardHeader>
                <CardContent>
                  <SalesChart />
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle>Product Distribution</CardTitle>
                  <CardDescription>Sales by product category</CardDescription>
                </CardHeader>
                <CardContent>
                  <ProductsChart />
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          <TabsContent value="reports">
            <Card>
              <CardHeader>
                <CardTitle>Generated Reports</CardTitle>
                <CardDescription>Download or view detailed reports</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <Button variant="outline" className="w-full justify-start">
                    <FileText className="mr-2 h-4 w-4" />
                    Monthly Sales Report (PDF)
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    <FileText className="mr-2 h-4 w-4" />
                    Product Performance Analysis (Excel)
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    <FileText className="mr-2 h-4 w-4" />
                    Customer Segmentation Report (PDF)
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          <TabsContent value="data">
            <Card>
              <CardHeader>
                <CardTitle>Raw Data</CardTitle>
                <CardDescription>View and export raw data</CardDescription>
              </CardHeader>
              <CardContent>
                <DataTable />
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      <FilterDrawer open={isFilterOpen} onClose={() => setIsFilterOpen(false)} />
    </div>
  )
}

